#!/bin/bash
cp /home/dylan/Seafile/My\ Library/Temp_Git_Files/Proxmox_SSH_Client/pve_ssh /home/dylan/.local/bin/pve_ssh
